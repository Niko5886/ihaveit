// Categories data (based on OLX.bg structure)
const categories = {
    buy: [
        { name: 'Електроника', icon: '📱', subcategories: ['Мобилни телефони', 'Компютри', 'Таблети', 'Аудио/Видео', 'Камери', 'Консоли и игри', 'Аксесоари'] },
        { name: 'Мода', icon: '👕', subcategories: ['Дамски дрехи', 'Мъжки дрехи', 'Детски дрехи', 'Обувки', 'Чанти', 'Бижута', 'Часовници'] },
        { name: 'Дом и градина', icon: '🏠', subcategories: ['Мебели', 'Декорация', 'Градински инструменти', 'Текстил', 'Осветление', 'Кухненски прибори'] },
        { name: 'Спорт', icon: '⚽', subcategories: ['Фитнес', 'Велосипеди', 'Зимни спортове', 'Водни спортове', 'Спортни обувки', 'Екипировка'] },
        { name: 'Книги', icon: '📚', subcategories: ['Художествена литература', 'Учебници', 'Детски книги', 'Комикси', 'Списания', 'Учебна литература'] },
        { name: 'Детски стоки', icon: '🍼', subcategories: ['Бебешки дрехи', 'Играчки', 'Детски мебели', 'Детски стоки', 'Колички'] },
        { name: 'Авто', icon: '🚗', subcategories: ['Автомобили', 'Мотори', 'Авточасти', 'Автоаксесоари', 'Гуми', 'GPS навигация'] },
        { name: 'Недвижими имоти', icon: '🏘️', subcategories: ['Апартаменти', 'Къщи', 'Гаражи', 'Парцели', 'Офиси', 'Магазини'] },
        { name: 'Домашни любимци', icon: '🐾', subcategories: ['Кучета', 'Котки', 'Птици', 'Риби', 'Гризачи', 'Аксесоари за животни'] },
        { name: 'Услуги', icon: '🛠️', subcategories: ['Ремонт', 'Почистване', 'Преподаване', 'Преводи', 'IT услуги', 'Фотография'] },
        { name: 'Хоби и свободно време', icon: '🎨', subcategories: ['Музикални инструменти', 'Художествени материали', 'Колекции', 'Билети'] },
        { name: 'Работа', icon: '💼', subcategories: ['Офис работа', 'IT', 'Продажби', 'Хотелиерство', 'Строителство', 'Образование'] },
        { name: 'Градски превоз', icon: '🚲', subcategories: ['Велосипеди', 'Тротинетки', 'Скейтборд', 'Аксесоари'] },
        { name: 'Музика и филми', icon: '🎬', subcategories: ['CD/DVD', 'Винил', 'Blu-ray', 'Концертни билети'] },
        { name: 'Строителство', icon: '🔨', subcategories: ['Инструменти', 'Материали', 'Машини', 'Електрооборудване'] },
        { name: 'Храна и напитки', icon: '🍔', subcategories: ['Хранителни продукти', 'Напитки', 'Био продукти', 'Добавки'] },
        { name: 'Красота и здраве', icon: '💄', subcategories: ['Козметика', 'Парфюми', 'Грижа за коса', 'Здравословни продукти'] },
        { name: 'Бизнес и индустрия', icon: '🏭', subcategories: ['Офис оборудване', 'Складова техника', 'Търговско оборудване'] },
        { name: 'Антики и колекции', icon: '🏺', subcategories: ['Антични вещи', 'Колекционерски предмети', 'Изкуство', 'Старинни книги'] },
        { name: 'Други', icon: '📦', subcategories: ['Разни', 'Безплатни', 'Размяна'] }
    ],
    sell: [
        { name: 'Електроника', icon: '📱', subcategories: ['Мобилни телефони', 'Компютри', 'Таблети', 'Аудио/Видео', 'Камери', 'Консоли и игри', 'Аксесоари'] },
        { name: 'Мода', icon: '👕', subcategories: ['Дамски дрехи', 'Мъжки дрехи', 'Детски дрехи', 'Обувки', 'Чанти', 'Бижута', 'Часовници'] },
        { name: 'Дом и градина', icon: '🏠', subcategories: ['Мебели', 'Декорация', 'Градински инструменти', 'Текстил', 'Осветление', 'Кухненски прибори'] },
        { name: 'Спорт', icon: '⚽', subcategories: ['Фитнес', 'Велосипеди', 'Зимни спортове', 'Водни спортове', 'Спортни обувки', 'Екипировка'] },
        { name: 'Книги', icon: '📚', subcategories: ['Художествена литература', 'Учебници', 'Детски книги', 'Комикси', 'Списания', 'Учебна литература'] },
        { name: 'Детски стоки', icon: '🍼', subcategories: ['Бебешки дрехи', 'Играчки', 'Детски мебели', 'Детски стоки', 'Колички'] },
        { name: 'Авто', icon: '🚗', subcategories: ['Автомобили', 'Мотори', 'Авточасти', 'Автоаксесоари', 'Гуми', 'GPS навигация'] },
        { name: 'Недвижими имоти', icon: '🏘️', subcategories: ['Апартаменти', 'Къщи', 'Гаражи', 'Парцели', 'Офиси', 'Магазини'] },
        { name: 'Домашни любимци', icon: '🐾', subcategories: ['Кучета', 'Котки', 'Птици', 'Риби', 'Гризачи', 'Аксесоари за животни'] },
        { name: 'Услуги', icon: '🛠️', subcategories: ['Ремонт', 'Почистване', 'Преподаване', 'Преводи', 'IT услуги', 'Фотография'] },
        { name: 'Хоби и свободно време', icon: '🎨', subcategories: ['Музикални инструменти', 'Художествени материали', 'Колекции', 'Билети'] },
        { name: 'Работа', icon: '💼', subcategories: ['Офис работа', 'IT', 'Продажби', 'Хотелиерство', 'Строителство', 'Образование'] },
        { name: 'Градски превоз', icon: '🚲', subcategories: ['Велосипеди', 'Тротинетки', 'Скейтборд', 'Аксесоари'] },
        { name: 'Музика и филми', icon: '🎬', subcategories: ['CD/DVD', 'Винил', 'Blu-ray', 'Концертни билети'] },
        { name: 'Строителство', icon: '🔨', subcategories: ['Инструменти', 'Материали', 'Машини', 'Електрооборудване'] },
        { name: 'Храна и напитки', icon: '🍔', subcategories: ['Хранителни продукти', 'Напитки', 'Био продукти', 'Добавки'] },
        { name: 'Красота и здраве', icon: '💄', subcategories: ['Козметика', 'Парфюми', 'Грижа за коса', 'Здравословни продукти'] },
        { name: 'Бизнес и индустрия', icon: '🏭', subcategories: ['Офис оборудване', 'Складова техника', 'Търговско оборудване'] },
        { name: 'Антики и колекции', icon: '🏺', subcategories: ['Антични вещи', 'Колекционерски предмети', 'Изкуство', 'Старинни книги'] },
        { name: 'Други', icon: '📦', subcategories: ['Разни', 'Безплатни', 'Размяна'] }
    ]
};

let currentAction = null;

// Select action (buy or sell)
function selectAction(action) {
    currentAction = action;
    
    // Hide action selection
    document.getElementById('actionSelection').classList.add('hidden');
    
    // Show categories
    const categoriesSection = document.getElementById('categoriesSection');
    categoriesSection.classList.remove('hidden');
    
    // Update title
    const title = action === 'buy' ? 'Какво искаш да купиш?' : 'Какво искаш да продадеш?';
    document.getElementById('categoryTitle').textContent = title;
    
    // Load categories
    loadCategories(action);
}

// Load categories
function loadCategories(action) {
    const categoriesGrid = document.getElementById('categoriesGrid');
    categoriesGrid.innerHTML = '';
    
    const categoryList = categories[action];
    
    categoryList.forEach((category, index) => {
        const categoryItem = document.createElement('div');
        categoryItem.className = 'category-item';
        categoryItem.style.animationDelay = `${index * 0.03}s`;
        categoryItem.onclick = () => selectCategory(category, action);
        
        categoryItem.innerHTML = `
            <div class="category-icon">${category.icon}</div>
            <div class="category-name">${category.name}</div>
            <div class="category-count">${category.subcategories.length} подкатегории</div>
        `;
        
        categoriesGrid.appendChild(categoryItem);
    });
}

// Select category
function selectCategory(category, action) {
    console.log(`${action === 'buy' ? '🛍️ Купувам' : '💰 Продавам'}:`, category.name);
    console.log('Подкатегории:', category.subcategories);
    
    // Store selected category and action
    localStorage.setItem('selected_action', action);
    localStorage.setItem('selected_category', JSON.stringify(category));
    
    // Redirect based on action
    if (action === 'buy') {
        // Go to swipe platform to browse items
        window.location.href = 'swipe.html';
    } else {
        // Go to create listing page
        window.location.href = 'create-listing.html';
    }
}

// Show action selection
function showActionSelection() {
    document.getElementById('actionSelection').classList.remove('hidden');
    document.getElementById('categoriesSection').classList.add('hidden');
    currentAction = null;
}

// Add animation class
const style = document.createElement('style');
style.textContent = `
    .category-item {
        animation: categoryFadeIn 0.4s ease-out forwards;
        opacity: 0;
    }
    
    @keyframes categoryFadeIn {
        to {
            opacity: 1;
        }
    }
`;
document.head.appendChild(style);

console.log('🏠 Home page loaded');
